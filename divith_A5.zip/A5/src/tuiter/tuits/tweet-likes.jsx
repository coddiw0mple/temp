import React from "react";
import {useDispatch} from "react-redux";
import {updateLike} from "../reducers/home-tuits-reducer.jsx";

const TweetLikes = ({liked, likes, id}) => {

    const dispatch = useDispatch();
    const updateLikeHandler = (id) => {
        dispatch(updateLike(id));
    }

    if (liked == true) {
        return (
            <i className="col-3 float-end bi bi-suit-heart-fill position-relative" style={{color: 'red'}} onClick={() => updateLikeHandler(id)}> {likes + 1}</i>
        );
    } else {
        return <i className="col-3 float-end bi bi-suit-heart position-relative light" onClick={() => updateLikeHandler(id)}> {likes}</i>
    }
}

export default TweetLikes;