import React from "react";
import {Routes, Route} from "react-router";

import Exercise5 from "./e5";
import Nav from "../nav.jsx";
import Exercise6 from "./e6/index.jsx";

function Exercises() {
    return(
        <div>
            <Nav />
            <Routes>
                <Route index
                       element={< Exercise5 />}/>
                <Route path="e6"
                       element={< Exercise6 />}/>
            </Routes>
        </div>
    );
}
export default Exercises;