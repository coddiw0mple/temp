import React from "react";

import reduxExamples from "./redux-examples/index.jsx";
import ReduxExamples from "./redux-examples/index.jsx";

const Exercise6 = () => {
    return(
        <>
            <h1>Exercise 6</h1>
            <ReduxExamples />
        </>
    );
};
export default Exercise6;