import {Link} from "react-router-dom";
function Nav() {
    return (
        <div>
            <Link to="/">Exercise 5</Link> |
            <Link to="/e6"> Exercise 6</Link> |
            <Link to="/tuiter">Tuiter</Link>
        </div>
    )
}
export default Nav;