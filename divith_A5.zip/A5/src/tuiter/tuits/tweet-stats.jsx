import React from "react";
import './tweet-stats.css'
import TweetLikes from "./tweet-likes.jsx";


const TweetStats = ({likes, retuits, comments, liked, id}) => {

    return (
        <div className="row-12">
            <i className="col-3 float-end bi bi-share position-relative light"></i>
            <TweetLikes likes={likes} liked={liked} id={id} />
            <i className="col-3 float-end bi bi-repeat position-relative light"> {retuits}</i>
            <i className="col-3 float-end bi bi-chat position-relative light"> {comments}</i>
        </div>
    );
};

export default TweetStats;