import React from 'react';
import Tweet from "../tuits/tweet.jsx";
import './index.css'
import TweetStats from "../tuits/tweet-stats.jsx";
import WhatsHappening from "./whats-happening.jsx";

import {useSelector} from "react-redux";

const HomeComponent= () => {
    const homeTuitsArray = useSelector(state => (state.home_tuits));

    return (
        <div className="col-12">
            <WhatsHappening/>
            <ul className="list-group">
                {
                    homeTuitsArray.map(tuit =>
                        <div key={tuit._id}>
                            <Tweet
                                userAvatar={tuit.image}
                                userName={tuit.userName}
                                userHandle={tuit.handle}
                                tweetText={tuit.tuit}
                                tweetImage={tuit.tuitImage}
                                timeAgo={tuit.time}
                                id={tuit._id}
                            />

                            <div style={{marginTop: '10px'}}>
                                <TweetStats likes={tuit.likes}
                                            retuits={tuit.retuits}
                                            comments={tuit.replies}
                                            liked={tuit.liked}
                                            id={tuit._id}
                                />
                            </div>
                        </div>
                    )
                }
            </ul>

            <div style={{marginBottom: '200px'}}>
                &nbsp;
            </div>
        </div>
    );
};
export default HomeComponent;
